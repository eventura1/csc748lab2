from boofuzz import *
 
def main():
 
 
    port = 9999
    host = '127.0.0.1'
    protocol = 'tcp'
     
    csv_log = open('fuzz_results.csv', 'w') 
    my_logger = [FuzzLoggerCsv(file_handle=csv_log)] 
 
 
     
    options = {"proc_name" : "vulnserver.exe", "stop_commands": ['wmic process where (name="vulnserver") delete'], "start_commands": ['C:\\bfuzz\\vulnserver.exe']}
    procmon = ProcessMonitor(host,26002)
    procmon.set_options(**options)
    monitors = [procmon]

    session = Session (
        target=Target(
            connection=SocketConnection(host,port, proto='tcp'),
            monitors=monitors
        ),
        sleep_time=1,
        fuzz_loggers=[FuzzLoggerText(),FuzzLoggerCsv(file_handle=csv_log)]
        )
 
 
 
    s_initialize("trun")
    s_string("TRUN", fuzzable=False)
    s_delim(" ", fuzzable=False)
    s_string("FUZZ")
    s_static("\r\n")
 
         
    session.connect(s_get("trun"))
    session.fuzz()
 
 
if __name__ == "__main__":
    main()